#ifndef ICON_H
#define ICON_H

#define WIN32_ICON_MAIN 1

#endif // ICON_H

